# MORPH-Exact / MORPH-Hyper

A proof-carrying prototype of **self-abstracting computation**.

Open deterministic synchronous Moore transducers are treated as computational atoms. The runtime discovers candidate organs from executable signal dependencies, counterfactually composes them, computes the exact minimal external behavior quotient, exhaustively verifies a re-atomization certificate, and promotes the quotient to a new atom of the same type. MORPH-Hyper additionally commits certified three-region organs to cross pairwise neutral barriers.

## Quick start

```bash
python -m pip install -e .
# 离线环境可使用：python -m pip install -e . --no-build-isolation --no-deps
pytest -q
```

Read:

- [`REPORT.md`](REPORT.md): Chinese research report, formal model, results, limitations and novelty boundary.
- [`REPRODUCE.md`](REPRODUCE.md): exact commands and raw evidence inventory.

The repository contains 2,500+ lines of Python, eight test groups, 10,000/1,000/500 exactness stress suites, a public LGSynth91 controller, natural XOR/modular-sum networks, baselines, and per-merge certificate ledgers.

No selected abstraction is statistical. If a candidate cannot be exhaustively certified within the declared finite resource budget, it is not installed.
